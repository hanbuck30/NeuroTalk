from .utils.func import metric_func
from .utils.sparseLIB import sparseESN
from .utils.func import check_dim, check_type, metric_func
from .config import parse_args
from .learning_algorithm import Gradient_descent